; Developed with assistance from DeepSeek AI for educational purposes in OS course slides
; Program with Procedure Vector Table (like interrupt vectors)
; Uses polling I/O with indirect BSA calls
; There is no indirect BSA in Mano's book, therefore we imagine it

        ORG     0
START   BSA     (PVT_INPUT)
        STA     NUM1
        BSA     (PVT_INPUT)
        STA     NUM2
        LDA     NUM1
        ADD     NUM2
        STA     RESULT
        BSA     (PVT_OUTPUT)
        HLT
NUM1,   DEC     0
NUM2,   DEC     0
RESULT, DEC     0

        ORG     150
PVT_INPUT,  HEX 200
PVT_OUTPUT, HEX 220

        ORG     200
INPUT,  HEX     0
IN_POLL,SKI
        BUN     IN_POLL
        INP
        BUN     (INPUT)

        ORG     220
OUTPUT, HEX     0
        STA     TEMP_OUT

OUT_POLL,SKO
        BUN     OUT_POLL
        LDA     TEMP_OUT
        OUT
        BSA     (PVT_DELAY)
        BUN     (OUTPUT)

        ORG     240
DELAY,  HEX     0
        LDA     DELAY_COUNT
        STA     DELAY_CTR

DELAY_LOOP,
        LDA     DELAY_CTR
        SZA
        BUN     CONTINUE_DELAY
        BUN     (DELAY)

CONTINUE_DELAY,
        DEC
        STA     DELAY_CTR
        BUN     DELAY_LOOP

        ORG     300
TEMP_OUT,   DEC     0
DELAY_COUNT,DEC     10
DELAY_CTR,  DEC     0
PVT_DELAY,  HEX     52
        END
