; Developed with assistance from DeepSeek AI for educational purposes in OS course slides
; Bootstrap Loader: ORG 0
; Reads program from input and executes it
; First input = number of bytes to read
; Subsequent inputs = program bytes stored starting at 128
; Then jumps to address 128 using BSA

        ORG     0

START,  BSA     READ_COUNT  // Read byte count from input
        STA     BYTE_COUNT  // Store the count
        
        BSA     INIT_LOAD   // Initialize loader
        BSA     LOAD_LOOP   // Load program bytes
        
        // Program loaded - now execute it
        BSA     EXECUTE     // Jump to loaded program
        
        HLT                 // Should not reach here normally

// Subroutine to read byte count from input
READ_COUNT, HEX 0
RD_CNT, SKI                 // Wait for input
        BUN     RD_CNT
        INP                 // Read byte count to AC
        BUN     READ_COUNT I // Return

// Subroutine to initialize loader
INIT_LOAD, HEX 0
        LDA     ZERO
        STA     LOAD_PTR    // Initialize pointer to 128
        STA     CURRENT_IDX // Initialize index
        BUN     INIT_LOAD I

// Subroutine to load program bytes
LOAD_LOOP, HEX 0
        // Check if all bytes loaded
        LDA     CURRENT_IDX
        SUB     BYTE_COUNT
        SPA                 // Skip if index >= count (done)
        BUN     LOAD_BYTE
        
        // Loading complete
        BUN     LOAD_LOOP I

LOAD_BYTE,
        BSA     READ_BYTE   // Read one byte
        STA     TEMP_BYTE   // Store temporarily
        
        // Store byte in memory
        LDA     LOAD_PTR
        STA     STORE_PTR
        LDA     TEMP_BYTE
        STA     STORE_PTR I // Store at [LOAD_PTR]
        
        // Increment pointer and index
        LDA     LOAD_PTR
        INC
        STA     LOAD_PTR
        LDA     CURRENT_IDX
        INC
        STA     CURRENT_IDX
        
        BUN     LOAD_LOOP   // Continue loading

// Subroutine to read one byte from input
READ_BYTE, HEX 0
RD_BYT, SKI                 // Wait for input
        BUN     RD_BYT
        INP                 // Read byte to AC
        BUN     READ_BYTE I // Return

// Subroutine to execute loaded program
EXECUTE, HEX 0
        // Use BSA to jump to loaded program at address 128
        // BSA will store return address, but we don't expect to return
        BSA     JUMP_TARGET
        
        // If we return here, halt the system
        HLT

// Jump target - this will be at address 128
        ORG     128
JUMP_TARGET, HEX 0
        // The loaded program starts here
        // BSA stores return address at 128, program code at 129
        // The loaded program should handle this appropriately
        
        // Example of what a loaded program might do:
        // (This would be replaced by the actual loaded code)
        LDA     ZERO
        STA     RESULT
        HLT

// Data Section (in lower memory)
        ORG     64          // Data area below program space
ZERO,       DEC     0
BYTE_COUNT, DEC     0       // Number of bytes to load
LOAD_PTR,   HEX     128     // Pointer to loading address
CURRENT_IDX,DEC     0       // Current byte index
TEMP_BYTE,  DEC     0       // Temporary storage
STORE_PTR,  HEX     0       // Pointer for indirect store
RESULT,     DEC     0       // For demo program

        END
