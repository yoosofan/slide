; Developed with assistance from DeepSeek AI for educational purposes in OS course slides
; Interrupt-driven program that gets loaded
; Has its own interrupt service routine

        ORG     0

MAIN,   // Main program - does useful work
        ION     // Enable interrupts
        LDA     ZERO
        STA     COUNTER
        
WORK_LOOP,
        LDA     COUNTER
        INC
        STA     COUNTER
        BUN     WORK_LOOP      // Continuous work
        
        HLT

// Program's Interrupt Service Routine at logical address 50
        ORG     50
PROG_ISR, HEX  0
        STA     PROG_SAVE_AC
        
        SKI
        BUN     PROG_CHECK_OUTPUT
        
        // Input for this program
        INP
        STA     PROG_INPUT_DATA
        BSA     PROCESS_INPUT
        BUN     PROG_ISR_EXIT
        
PROG_CHECK_OUTPUT,
        SKO
        BUN     PROG_ISR_EXIT
        
        // Output ready - send data if available
        LDA     PROG_OUTPUT_DATA
        SZA
        BUN     SEND_PROG_OUTPUT
        BUN     PROG_ISR_EXIT
        
SEND_PROG_OUTPUT,
        OUT
        LDA     ZERO
        STA     PROG_OUTPUT_DATA
        
PROG_ISR_EXIT,
        ION
        LDA     PROG_SAVE_AC
        BUN     PROG_ISR I

// Input Handler at logical address 100
        ORG     100
PROG_INPUT_HANDLER, HEX 0
        // Process input data
        LDA     PROG_INPUT_DATA
        STA     CURRENT_INPUT
        BUN     PROG_INPUT_HANDLER I

// Output Handler at logical address 120
        ORG     120
PROG_OUTPUT_HANDLER, HEX 0
        // Prepare output data
        LDA     CURRENT_INPUT
        ADD     ONE
        STA     PROG_OUTPUT_DATA
        BUN     PROG_OUTPUT_HANDLER I

// Process Input Subroutine
PROCESS_INPUT, HEX 0
        // Process the input character
        BUN     PROCESS_INPUT I

// Data Section for loaded program
        ORG     200
PROG_SAVE_AC,   DEC     0
PROG_INPUT_DATA,DEC     0
PROG_OUTPUT_DATA,DEC    0
CURRENT_INPUT,  DEC     0
COUNTER,        DEC     0
ZERO,           DEC     0
ONE,            DEC     1

        END
