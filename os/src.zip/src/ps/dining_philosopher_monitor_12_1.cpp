void putdown(int i){
